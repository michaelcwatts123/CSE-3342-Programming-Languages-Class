//
//  point.hpp
//  GameForPL
//
//  Created by Michael Watts on 3/23/18.
//  Copyright © 2018 Michael Watts. All rights reserved.
//

#ifndef point_hpp
#define point_hpp

#include <stdio.h>
class point { //holds x y coordinates of point
public:
    int x;
    int y;
};
#endif /* point_hpp */
