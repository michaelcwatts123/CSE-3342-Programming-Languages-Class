//
//  main.cpp
//  GameForPL
//
//  Created by Michael Watts on 3/23/18.
//  Copyright © 2018 Michael Watts. All rights reserved.
//

#include <iostream>
#include "Game.hpp"
int main(int argc, const char * argv[]) {
    Game g; //creates instance of g class
    g.init(); //plays game
    return 0;
}

