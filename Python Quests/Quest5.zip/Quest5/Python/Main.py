from IGame import Game
g = Game()
